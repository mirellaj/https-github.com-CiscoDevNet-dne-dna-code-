"""Run a Python script from the Terminal by passing it to the Interpreter."""

print("Hello Python!!  ...at least I didn't say World.")
